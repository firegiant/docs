CREATE TABLE Test (Value1 CHAR(50), Value2 INTEGER)
CREATE INDEX TestIndex ON Test (Value1)
