﻿namespace WiXLocalizationHelper
{
	partial class MainWindow
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tbOriginalFile = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btSetOriginalFile = new System.Windows.Forms.Button();
			this.btPartialFile = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.tbPartial = new System.Windows.Forms.TextBox();
			this.btCreateNewTrans = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.tbCulture = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// tbOriginalFile
			// 
			this.tbOriginalFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
									| System.Windows.Forms.AnchorStyles.Right)));
			this.tbOriginalFile.Location = new System.Drawing.Point(165, 16);
			this.tbOriginalFile.Name = "tbOriginalFile";
			this.tbOriginalFile.Size = new System.Drawing.Size(318, 20);
			this.tbOriginalFile.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 19);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(131, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Language to be translated";
			// 
			// btSetOriginalFile
			// 
			this.btSetOriginalFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btSetOriginalFile.Location = new System.Drawing.Point(489, 14);
			this.btSetOriginalFile.Name = "btSetOriginalFile";
			this.btSetOriginalFile.Size = new System.Drawing.Size(22, 23);
			this.btSetOriginalFile.TabIndex = 2;
			this.btSetOriginalFile.Text = "...";
			this.btSetOriginalFile.UseVisualStyleBackColor = true;
			this.btSetOriginalFile.Click += new System.EventHandler(this.btSetOriginalFile_Click);
			// 
			// btPartialFile
			// 
			this.btPartialFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btPartialFile.Location = new System.Drawing.Point(489, 69);
			this.btPartialFile.Name = "btPartialFile";
			this.btPartialFile.Size = new System.Drawing.Size(22, 23);
			this.btPartialFile.TabIndex = 5;
			this.btPartialFile.Text = "...";
			this.btPartialFile.UseVisualStyleBackColor = true;
			this.btPartialFile.Click += new System.EventHandler(this.btPartialFile_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 74);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Partial transtalate";
			// 
			// tbPartial
			// 
			this.tbPartial.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
									| System.Windows.Forms.AnchorStyles.Right)));
			this.tbPartial.Location = new System.Drawing.Point(165, 71);
			this.tbPartial.Name = "tbPartial";
			this.tbPartial.Size = new System.Drawing.Size(318, 20);
			this.tbPartial.TabIndex = 3;
			// 
			// btCreateNewTrans
			// 
			this.btCreateNewTrans.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
									| System.Windows.Forms.AnchorStyles.Right)));
			this.btCreateNewTrans.Location = new System.Drawing.Point(15, 178);
			this.btCreateNewTrans.Name = "btCreateNewTrans";
			this.btCreateNewTrans.Size = new System.Drawing.Size(496, 51);
			this.btCreateNewTrans.TabIndex = 6;
			this.btCreateNewTrans.Text = "Create new translation using partial translate";
			this.btCreateNewTrans.UseVisualStyleBackColor = true;
			this.btCreateNewTrans.Click += new System.EventHandler(this.btCreateNewTrans_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(162, 39);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(155, 13);
			this.label3.TabIndex = 1;
			this.label3.Text = "e.g. WiX 3 WixUI_en-us.wxl file";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(162, 94);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(154, 13);
			this.label4.TabIndex = 7;
			this.label4.Text = "e.g. WiX 2 WixUI_cs-cz.wxl file";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 131);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 13);
			this.label5.TabIndex = 8;
			this.label5.Text = "Culture";
			// 
			// tbCulture
			// 
			this.tbCulture.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
									| System.Windows.Forms.AnchorStyles.Right)));
			this.tbCulture.Location = new System.Drawing.Point(165, 124);
			this.tbCulture.Name = "tbCulture";
			this.tbCulture.Size = new System.Drawing.Size(318, 20);
			this.tbCulture.TabIndex = 9;
			this.tbCulture.Text = "cs-cz";
			// 
			// MainWindow
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(523, 241);
			this.Controls.Add(this.tbCulture);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.btCreateNewTrans);
			this.Controls.Add(this.btPartialFile);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.tbPartial);
			this.Controls.Add(this.btSetOriginalFile);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbOriginalFile);
			this.Name = "MainWindow";
			this.Text = "MainWindow";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox tbOriginalFile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btSetOriginalFile;
		private System.Windows.Forms.Button btPartialFile;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbPartial;
		private System.Windows.Forms.Button btCreateNewTrans;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox tbCulture;
	}
}