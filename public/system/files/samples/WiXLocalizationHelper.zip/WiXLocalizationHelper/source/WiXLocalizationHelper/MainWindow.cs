﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ESG.Persistence.Xml;
using System.IO;
using System.Xml;

namespace WiXLocalizationHelper
{
	public partial class MainWindow : Form
	{
		public Dictionary<string, string> m_Original;
		public Dictionary<string, string> m_Partial;

		public MainWindow()
		{
			InitializeComponent();
		}

		private void btSetOriginalFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog od = new OpenFileDialog();
			od.FileName = tbOriginalFile.Text;
			if (od.ShowDialog() == DialogResult.OK)
			{
				tbOriginalFile.Text = od.FileName;
			}
		}

		private void btPartialFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog od = new OpenFileDialog();
			od.FileName = tbPartial.Text;
			if (od.ShowDialog() == DialogResult.OK)
			{
				tbPartial.Text = od.FileName;
			}
		}

		private Dictionary<string, string> LoadWixLocalization(string fileName)
		{
			Dictionary<string, string> dict = new Dictionary<string, string>();
			if (File.Exists(fileName))
			{
				using (StreamReader sr = new StreamReader(fileName))
				{
					XmlBuilder document = XmlBuilder.LoadDocument(sr);
					if (document != null)
					{
						XmlBuilderNode root = document.RootElement;

						if (root != null && root.Tag == "WixLocalization")
						{
							foreach (XmlBuilderNode str in root.GetChildElements("String"))
							{
								dict.Add(str.GetAttributeValue("Id"), str.InnerText);
							}
						}
					}
				}
			}

			return dict;
		}

		private void SaveWiXLocalization(Dictionary<string, string> dict, string fileName)
		{
			XmlTextWriter xmlWriter = new XmlTextWriter(fileName, System.Text.Encoding.UTF8);
			xmlWriter.Formatting = Formatting.Indented;
			xmlWriter.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");
			xmlWriter.WriteComment("\n    Copyright (c) Microsoft Corporation.  All rights reserved.\n\n    The use and distribution terms for this software are covered by the\n    Common Public License 1.0 (http://opensource.org/licenses/cpl.php)\n    which can be found in the file CPL.TXT at the root of this distribution.\n    By using this software in any fashion, you are agreeing to be bound by\n    the terms of this license.\n\n    You must not remove this notice, or any other, from this software.\n");
			xmlWriter.WriteStartElement("WixLocalization", "http://schemas.microsoft.com/wix/2006/localization");
			xmlWriter.WriteAttributeString("Culture", tbCulture.Text);

			foreach (KeyValuePair<string, string> kvp in dict)
			{
				xmlWriter.WriteStartElement("String");
				xmlWriter.WriteAttributeString("Id", kvp.Key);
				xmlWriter.WriteAttributeString("Overridable", "yes");
				xmlWriter.WriteString(kvp.Value);
				xmlWriter.WriteEndElement();
			}
			xmlWriter.Close();
		}

		private void btCreateNewTrans_Click(object sender, EventArgs e)
		{
			m_Original = LoadWixLocalization(tbOriginalFile.Text);
			m_Partial = LoadWixLocalization(tbPartial.Text);
			Dictionary<string, string> m_NotTanslated = new Dictionary<string, string>(m_Original);

			foreach (KeyValuePair<string, string> kvp in m_Partial)
			{
				if (m_Original.ContainsKey(kvp.Key))
				{
					m_Original[kvp.Key] = kvp.Value;
					m_NotTanslated.Remove(kvp.Key);
				}
			}

			SaveWiXLocalization(m_NotTanslated, "TODO.wxl");

			using (TextWriter tw = new StreamWriter("PureText.txt", false, Encoding.UTF8))
			{
				foreach (KeyValuePair<string, string> kvp in m_Original)
				{
					tw.WriteLine(kvp.Value.Replace("&", ""));
				}
			}

			MessageBox.Show(string.Format("String count: {0}\nTranslated: {1}\nNot translated: {2}\n\nNot translated strings were saved into file {3}\\TODO.wxl\n\nYour translation texts were saved into file {3}\\PureText.txt\n\nSelect resulting WixLocalization file location in the following dialog.", m_Original.Count, m_Original.Count - m_NotTanslated.Count, m_NotTanslated.Count, Application.StartupPath));

			SaveFileDialog sd = new SaveFileDialog();
			sd.FileName = string.Format("WixUI_{0}.wxl", tbCulture.Text);
			if (sd.ShowDialog() == DialogResult.OK)
			{
				SaveWiXLocalization(m_Original, sd.FileName);
			}
		}
	}
}
